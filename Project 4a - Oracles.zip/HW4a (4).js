function generateInput(n){

  function randomInt(min, max) {
    return Math.floor(Math.random() * (max - min)) + min;
  }

  let arr = [];
  let i = 0;
  while(i < n){
    let randArr = [];
    while(randArr.length < n){
      let rand = randomInt(0, n);
      if(!randArr.includes(rand)){
        randArr.push(rand);
      }
    }
    ++i;
    arr.push(randArr);
  }
  return arr;
}
console.log(generateInput(4));

//oracle(f: (companies: number[][], candidates: number[][]) => Hire[]): void
function oracle(f) {
  let numTests = 20; 
  for (let i = 0; i < numTests; ++i) {
    let n = 6; 
    let comps = generateInput(n);
    let cands = generateInput(n);
    let hire = f(comps, cands);
    test('Hire length is correct', function() {
      assert(n === hire.length);
    }); 

    test('Hire length is the same as company and candidate length', function(){
      assert(hire.length === comps.length && hire.length === cands.length);
    });

    test('No Duplicates in Array', function() {
      for(let i = 0; i < n; ++i){
        let comArr = [];
        let canArr = [];
        for(let j = 0; j < n; ++j){
          assert(!comArr.includes(comps[i][j]));
          assert(!canArr.includes(cands[i][j]));
          comArr.push(comps[i][j]);
          canArr.push(cands[i][j]);
        }
      }
    }); 
    test('Testing stable matching', function() {

      for(let i = 0; i < n; ++i){
        let comp = hire[i].company; 
        let cand = hire[i].candidate; 
        let currComp = comps[comp]; 
               
        for(let j = 0; j < n; ++j){ 
          let comp2 = hire[j].company; 
          let cand2 = hire[j].candidate; 
          let next = cands[cand2]; 
          let priority1 = currComp.indexOf(cand); 
          let priority2 = currComp.indexOf(cand2);
          let candidate1 = next.indexOf(comp); 
          let candidate2 = next.indexOf(comp2); 
          assert(!(priority2 < priority1 && candidate1 < candidate2));
         
        }
      }
    }); 
    
  }
}

oracle(wheat1);
// let n = 20; // Change this to some reasonable size
// let companies = generateInput(n);
// let candidates = generateInput(n);
// let hires = chaff1(companies, candidates);
// console.log(companies);
// console.log(candidates);
// console.log(hires);

oracle(chaff1);
