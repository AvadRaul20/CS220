class FluentRestaurants{
  constructor(jsonData) {
    this.data = jsonData;
  }

//fromState(stateStr: string): FluentRestaurants
//returns all the restaurants from the specified stateStr
  fromState(stateStr){
    return new FluentRestaurants(this.data.filter(a => lib220.getProperty(a, 'state').found && a.state === stateStr));
  }

// ratingLeq(rating: number): FluentRestaurants
//returns all the locations with a rating less than or equal to specified rating
  ratingLeq(rating){
    return new FluentRestaurants(this.data.filter(a => lib220.getProperty(a, 'stars').found && a.stars <= rating));
  }

// ratingGeq(rating: number): FluentRestaurants
//returns all the locations with a rating greater than or equal to specified rating
  ratingGeq(rating){
    return new FluentRestaurants(this.data.filter(a => lib220.getProperty(a, 'stars').found && a.stars >= rating));
  }

// category(categoryStr: string): FluentRestaurants
//returns all the restaurants which are applicable to the specified categoryStr
  category(categoryStr){
    return new FluentRestaurants(this.data.filter(a => lib220.getProperty(a, 'categories').found && a.categories.some(x => x === categoryStr)));
  }
// hasAmbience(ambienceStr: string): FluentRestaurants
//returns all the places that have the specified ambienceStr
  hasAmbience(ambienceStr){
    return new FluentRestaurants(this.data.filter(a => lib220.getProperty(a, 'Attributes').found && 
    lib220.getProperty(a.Attributes, 'Ambience').found && 
    lib220.getProperty(a.Attributes.Ambience, ambienceStr).found && 
    lib220.getProperty(a.Attributes.Ambience, ambienceStr).value));
  }

// bestPlace(): Restaurant | {}
//returns the place with the best stars, and if there are multiple locations with the equal highest stars in the list
//then it checks for the one with the most reviews. Further if the reviews are also the same, then it returns the first
//in the list.  
  bestPlace(){
    if(this.data.length === 0){
      return {};
    }
    let resList = this.data;

    let res = resList.reduce((acc, e) => lib220.getProperty(acc, 'stars').found && 
    lib220.getProperty(e, 'stars').found && 
    acc.stars > e.stars && resList.length > 0 ? acc : e, 
    resList[0]).stars;

    resList = resList.filter(a => lib220.getProperty(a, 'stars').found && a.stars === res);

    let lowestRev = resList.reduce((acc, e) => lib220.getProperty(acc, 'review_count').found && 
    lib220.getProperty(e, 'review_count').found && 
    lib220.getProperty(acc, 'review_count').value > e.review_count && 
    resList.length !== 0 ? acc : e, resList[0]).review_count;
    
    resList = resList.filter(a => lib220.getProperty(a, 'review_count').found && lib220.getProperty(a, 'review_count').value === lowestRev);
    return resList[0];

  }

// mostReviews(): Restaurant | {}
//Similar to best place, it also checks for the location with the highest reviews on the list
//and if there are multiple places with the same number of highest reviews then it will 
//see the number of stars. If the stars are also the same, then it will return the first element
//in the list with the highest reviews and then stars
  mostReviews(){
    let objList = this.data;

    if(this.data.length === 0){
      return {};
    }

    let res = objList.reduce((acc, e) => lib220.getProperty(acc, 'review_count').found && 
    lib220.getProperty(e, 'review_count').found && acc.review_count > e.review_count ? acc : e, 
    objList[0]);

    let resList = objList.filter(a => lib220.getProperty(a, 'review_count').found && a.review_count === res.review_count);

    if(resList.length > 1){

      let lowestRev = resList.reduce((acc, e) => lib220.getProperty(acc, 'stars').found && 
      lib220.getProperty(e, 'stars').found && 
      acc.stars > e.stars ? acc : e, 
      resList[0]);

      resList = resList.filter(a => lib220.getProperty(a, 'stars').found && lib220.getProperty(lowestRev, 'stars').value === lowestRev.stars);
    }

    return resList[0];
  }
}

// TESTING
const testData = [
{
 name: "Applebee's",
 state: "NC",
 stars: 7,
 review_count: 10,
 categories: ["American Restaurant"],
 Attributes: {
    Ambience: {
      hipster: false,
      trendy: true,
      upscale: false,
      casual: false
    }
 },
 },
 {
 name: "Pineapplebee's",
 state: "NC",
 stars: 7,
 review_count: 10,
 categories: ["Hawaiian Restaurant"],
 },
 {
 name: "China Garden",
 state: "NC",
 stars: 7,
 review_count: 5,
 categories: ["Asian Restaurant"],
 Attributes: {
  Ambience: {
    hipster: false,
    trendy: true,
    upscale: true,
    casual: false
  }
 }, 
 },
 {
 name: "Beach Ventures Roofing",
 state: "AZ",
 stars: 6,
 review_count: 30,
 },
 {
 name: "Alpaul Automobile Wash",
 state: "NC",
 stars: 3,
 review_count: 30,
 categories: ["Car wash"],
 Attributes: {
    Ambience: {
      hipster: false,
      trendy: true,
      upscale: false,
      casual: true
    }
 },
 }
];
//Checks if from state is filtering only the restaurants from the specified state
test('fromState filters correctly', function() {
 let tObj = new FluentRestaurants(testData);
 let list = tObj.fromState('NC').data;
 assert(list.length === 4);
 assert(list[0].name === "Applebee's");
 assert(list[1].name === "Pineapplebee's");
 assert(list[2].name === "China Garden");
 assert(list[3].name === "Alpaul Automobile Wash");
});

//Checks if fromState is able to filter through the elemnts with a field state
//as well as the case that there is no objects in the list
test('Edge Cases: fromState filters properly even if there is an object with no state field and if an object with no field as state exists',function(){
let fromStateTest1 = [];
let tObj = new FluentRestaurants(fromStateTest1);
let list = tObj.fromState('NC').data;
assert(list.length===0);

let fromStateTest2 = [{name: "Pancake house", stars: 3}, {name: "House of Pancakes", state: 'NC', stars: 4}];
let tObj2 = new FluentRestaurants(fromStateTest2);
let list2 = tObj2.fromState('NC').data;
assert(list2.length === 1);
assert(list2[0].name === "House of Pancakes");
});
  
//Checks if ratingLeq is correctly filtering for all the elements which have a rating that is less than or equal to a certain value
test('ratingLeq filters correctly', function() {
 let tObj = new FluentRestaurants(testData);
 let list = tObj.ratingLeq(3).data;
 assert(list.length === 1);
 assert(list[0].name === "Alpaul Automobile Wash");
 assert(list.every(x => x.stars <= 3));
});

//Checks if ratingLeq is correctly filtering for all the elements which have a rating that is greater than or equal to a certain value
test('ratingGeq filters correctly 1', function() {
 let tObj = new FluentRestaurants(testData);
 let list = tObj.ratingGeq(7).data;
 assert(list.length === 3);
 assert(list[0].name === "Applebee's");
 assert(list[1].name === "Pineapplebee's");
 assert(list[2].name === "China Garden");
 assert(list.every(x => x.stars >= 7));
});

//Checking for the same thing as ratingGeq 1 but checks if no elements are found in the case that the value is higher than
//the highest star rating in the list of objects.
test('ratingGeq filters correctly 2', function() {
 let tObj = new FluentRestaurants(testData);
 let list = tObj.ratingGeq(8).data;
 assert(list.length === 0);
});

//Like ratingGeq it ensure that an empty list is returned under the circumstance that the list of objects is empty.
test('ratingGeq filters correctly 3', function() {
 let tObj = new FluentRestaurants([]);
 let list = tObj.ratingGeq(8).data;
 assert(list.length === 0);
});

//Checking to see if it still identifies the correct ratingGeq elements even though there 
//are elements which do not have the stars field.
test('Edge Case: Checking even if there are elements with no stars data', function() {
 let tObj = new FluentRestaurants([{name: "Hi", review_count: 5},{name: "Bye", stars: 9, review_count: 2}]);
 let list = tObj.ratingGeq(8).data;
 assert(list.length === 1);
 assert(list.every(x => x.stars >= 8));
});

//Checks to see if the all the elements returned by the category method is only of that
//specified category.
test('category filters correctly and all places include the category', function() {
 let tObj = new FluentRestaurants(testData);
 let list = tObj.category('Car wash').data;
 assert(list.length === 1);
 assert(list[0].name === "Alpaul Automobile Wash");
 assert(list.every(x => x.categories.includes('Car wash')));
});

//There are two parts to this test. One checks if it gets all the places with a certain Ambience and the  
//next one checks if it goes even more in depth and gets the places which have both the categories
test('hasAmbience filters correctly', function() {
 let tObj = new FluentRestaurants(testData);
 let list = tObj.hasAmbience("trendy").data;
 assert(list.length === 3);
 assert(list[0].name === "Applebee's");
 assert(list[1].name === "China Garden");
 assert(list[2].name === "Alpaul Automobile Wash");
 assert(list.every(x => x.Attributes.Ambience.trendy));

 let tObj2 = new FluentRestaurants(testData);
 let list2 = tObj2.hasAmbience('trendy').hasAmbience("casual").data;
 assert(list2.length === 1);
 assert(list2[0].name === "Alpaul Automobile Wash");
 assert(list2.every(x => x.Attributes.Ambience.trendy && x.Attributes.Ambience.casual));
 });

 //This edge case checks if an empty list is returned in the case that there are 
 //no elements with that category.
test('Edge Case: if no element even contains the attribute', function() {
 let tObj = new FluentRestaurants(testData);
 let list = tObj.hasAmbience("crazy").data;
 assert(list.length === 0);
 });

 //Checks if bestPlace works with the test data by manual checking
 //Edge cases present check for if the method still identifies the correct place after filtering a list
 //Also check for if the method returns an empty object under the case that the list is empty. 
test('bestPlace is working (All Cases including edges)', function() {
  let tObj = new FluentRestaurants(testData);
  let list = tObj.data
  tObj.data[1].stars = 5;
  tObj.data[2].stars = 4;
  let obj = tObj.bestPlace();
  assert(obj.name === "Applebee's");

  let tObj2 = new FluentRestaurants(testData);
  let obj2 = tObj2.fromState('AZ').bestPlace();
  assert(obj2.name === "Beach Ventures Roofing")

  let tObj3 = new FluentRestaurants([]);
  let obj3 = tObj3.bestPlace();
  assert(Object.keys(obj3).length === 0);
});

//
test('bestPlace tie-breaking', function() {
 let tObj = new FluentRestaurants(testData);
 let place = tObj.fromState('NC').bestPlace();
 assert(place.name === "Applebee's");
 assert(place.state === "NC" && place.stars === 7 && place.categories.includes("American Restaurant") && place.Attributes.Ambience.trendy)
});

//all these mostReview tests are for checking for different edge cases:
//making sure that the tie is breaking for the correct cases
test('mostReviews is working 1', function() {
 let tObj = new FluentRestaurants(testData);
 tObj.data[3].review_count = 15
 let place = tObj.mostReviews();
 assert(place.name === "Alpaul Automobile Wash");
});

test('mostReviews is working 2', function() {
 let tObj = new FluentRestaurants(testData);
 tObj.data[3].review_count = 30
 let place = tObj.mostReviews();
 assert(place.name === "Beach Ventures Roofing");
});

 let tObj = new FluentRestaurants(testData);
 let place = tObj.mostReviews();
 console.log(place)

 //Checking for tie breaking
test('mostReviews tie-breaking', function() {
 let tObj = new FluentRestaurants(testData);
 let place = tObj.fromState('NC').mostReviews();
 assert(place.name === "Alpaul Automobile Wash");
});

