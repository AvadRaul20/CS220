let robot = lib220.loadImageFromURL('https://people.cs.umass.edu/~joydeepb/robot.jpg');

//removeBlueAndGreen(robot: Image): Image
function removeBlueAndGreen(robot){
 let roboCopy = robot.copy();
  for (let i = 0; i < roboCopy.width; ++i) {
    for (let j = 0; j < roboCopy.height; ++j) {
      let a = roboCopy.getPixel(i,j);
      roboCopy.setPixel(i, j, [a[0], 0.0, 0.0]);
    }
  }
return roboCopy;
}

//shiftRGB(robot: Image): Image
function shiftRGB(robot){
  let roboCopy = robot.copy();
  for(let i = 0; i < roboCopy.width ; ++i){
    for(let j = 0; j < roboCopy.height ; ++j){
      let pixels = roboCopy.getPixel(i, j);
      roboCopy.setPixel(i, j, [pixels[1], pixels[2], pixels[0]]);
    }
  }
  return roboCopy;
}

//imageMap(img: Image, func: (p : Pixel) => Pixel) : Image
function imageMap(img, func){
  let imgCopy = img.copy();
  for(let i = 0; i < imgCopy.width; ++i){
    for(let j = 0; j < imgCopy.height; ++j){
      let p = imgCopy.getPixel(i, j);
      let newP = func(p);
      imgCopy.setPixel(i, j, newP);
    }
  }
  return imgCopy;
}

//mapToRed(img: Image): Image
function mapToRed(img){
  return imageMap(img, p => [p[0], 0, 0]);
}

//mapToGBR(img: Image): Image
function mapToGBR(img){
  return imageMap(img, p => [p[1], p[2], p[0]]);
}

//increaseContrast(img: Image) : Image
function increaseContrast(img){
  return imageMap(img, function (p) { return p.map(x=>{
        if(x > 0.5){
      x += 0.1*(1 - x);
    }
    else{
      x += 0.1*(0 - x);
    }
    return x;
  });})
}

robot.show();

let antiWallE = removeBlueAndGreen(robot);
antiWallE.show();

let RGBshiftWallE = shiftRGB(robot);
RGBshiftWallE.show();

let quickRedWallE = mapToRed(robot);
quickRedWallE.show();

let quickAntiWallE = mapToGBR(robot);
quickAntiWallE.show();

let highContrastWallE = increaseContrast(robot);
highContrastWallE.show();

// Tests
test('Checking completion of code', function() {
  const test = lib220.createImage(10, 10, [1, 1, 1]);
  removeBlueAndGreen(test).getPixel(0, 0);
  // no assertion, just checks that the code runs to completion
})

test('Checking code completion of mapToRed', function() {
  const test = lib220.createImage(10, 10, [1, 1, 1]);
  mapToRed(test).getPixel(0, 0);
  // no assertion, just checks that the code runs to completion
})

test('Checking code completion of mapToGBR', function() {
  const test = lib220.createImage(10, 10, [1, 1, 1]);
  mapToGBR(test).getPixel(0, 0);
  // no assertion, just checks that the code runs to completion
})

test('removeBlueAndGreen is sucessful and WALL-E is red', function() {
  // Create a test image, of size 10 pixels x 10 pixels, and set it to all white.
  const test = lib220.createImage(10, 10, [1, 1, 1]);
  // Get the result of the function.
  const test_res = removeBlueAndGreen(test);
  // Read the center pixel.
  const pixelValue = test_res.getPixel(5, 5);
  // The red channel should be changed.
  assert(pixelValue[0] === 1);
  // The green channel should be 0.
  assert(pixelValue[1] === 0);
  // The blue channel should be 0.
  assert(pixelValue[2] === 0);
})

test('RGB shifted to GBR by shiftRGB function', function() {
  // Create a test image, of size 10 pixels x 10 pixels, and set RGB to some test values.
  const test = lib220.createImage(10, 10, [.6, .3, .8]);
  // Get the result of the function.
  const test_res = shiftRGB(test);
  // Read the center pixel.
  const pixelValue = test_res.getPixel(5, 5);
  //Check pixel Equality between test pixel and calculated value
  assert(pixelEq(pixelValue, [0.3, 0.8, 0.6]));

})

function pixelEq (p1, p2) {
  const epsilon = 0.002;
  for (let i = 0; i < 3; ++i) {
    if (Math.abs(p1[i] - p2[i]) > epsilon) {
      return false;
    }
  }
  return true;
}

test('Checking pixel equality', function() {
  const inputPixel = [0.5, 0.5, 0.5]
  // Create a test image, of size 10 pixels x 10 pixels, and set it to the inputPixel
  const image = lib220.createImage(10, 10, inputPixel);
  // Process the image.
  const outputImage = removeBlueAndGreen(image);
  // Check the center pixel.
  const centerPixel = outputImage.getPixel(5, 5);
  assert(pixelEq(centerPixel, [0.5, 0, 0]));
  // Check the top-left corner pixel.
  const cornerPixel = outputImage.getPixel(0, 0);
  assert(pixelEq(cornerPixel, [0.5, 0, 0]));
})


test('mapToRed using ImageMap works', function() {
  // Create a test image, of size 10 pixels x 10 pixels, and set it to all white.
  const test_img = lib220.createImage(10,10, [1, 1, 1]);
  //Call mapToRed to get result image.
  const red_img = mapToRed(test_img);
  //Obtaining pixel in order to test assertion. 
  const redImgP = red_img.getPixel(5, 5);
  //Asserting if test pixel is the same as a red pixel. 
  assert(pixelEq(redImgP, [1, 0, 0]));
})

test('mapToGBR using ImageMap works', function() {
  // Create a test image, of size 10 pixels x 10 pixels, and set it to all to random values
  const test_img = lib220.createImage(10, 10, [0.6, 0.2, 0.3]);
  //Call mapToGBR to get result image.
  const shiftRGBRes = mapToGBR(test_img);
  //Obtaining pixel in order to test assertion. 
  const shiftRGBResP = shiftRGBRes.getPixel(5, 5);
  //Asserting if test pixel is the same as expected value. 
  assert(pixelEq(shiftRGBResP, [0.2, 0.3, 0.6]));
})



test('Contrast of image increased by increaseContrast function', function() {
  // Create a test image, of size 10 pixels x 10 pixels, and set it to all to random test values
  const test_img = lib220.createImage(10, 10, [0.3, 0.6, 0.1])
  //Call increaseContrast to get result image.
  const result = increaseContrast(test_img);
  //Obtaining pixel in order to test assertion. 
  const resultP = result.getPixel(5, 5);
  //Asserting if test pixel is the same as expected value. 
  assert(pixelEq(resultP, [0.27, 0.64, 0.09]));
})
