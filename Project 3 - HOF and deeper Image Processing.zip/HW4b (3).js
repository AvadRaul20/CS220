//generateInput(n: number): number[][]
function generateInput(n){

  function randomInt(min, max) {
    return Math.floor(Math.random() * (max - min)) + min;
  }

  let arr = [];
  let i = 0;
  while(i < n){
    let randArr = [];
    while(randArr.length < n){
      let rand = randomInt(0, n);
      if(!randArr.includes(rand)){
        randArr.push(rand);
      }
    }
    ++i;
    arr.push(randArr);
  }
  return arr;
}

//runOracle(f: (companies: number[][], candidates: number[][]) => Run): void
function runOracle(f){
  let numTests = 20; 
  let co = generateInput(6);
  let ca = generateInput(6);
  for (let i = 0; i < numTests; ++i){
    let n = 6; 
    let comps = generateInput(n);
    let cands = generateInput(n);
    let run = f(comps, cands);


    test('Companies and Candidates have equal length and is equal to n', function(){
      assert(comps.length === cands.length && cands.length === n);
    });

    test('Checking for duplicates', function(){
      function helper(arr){
        return arr.some(bool => {
          return arr.indexOf(bool) !== arr.lastIndexOf(bool);
        });
      }
      assert(!helper(run.trace))
    });
  }
  test('lengths', function(){
    let hires = f(co, ca);
      let companies=[];
      let candidates=[];
      for(let i=0;i<hires.trace.length;++i){
        if(hires.trace[hires.trace.length-i-1].fromCo){
          if(!companies.includes(hires.trace[hires.trace.length-i-1].from) && !candidates.includes(hires.trace[hires.trace.length-i-1].to)){
            companies.push(hires.trace[hires.trace.length-i-1].from);
            candidates.push(hires.trace[hires.trace.length-i-1].to);
          }
        }
        else{
          if(!companies.includes(hires.trace[hires.trace.length-i-1].to) && !candidates.includes(hires.trace[hires.trace.length-i-1].from)){
            companies.push(hires.trace[hires.trace.length-i-1].to);
            candidates.push(hires.trace[hires.trace.length-i-1].from);
          }
        }
        
      }
      assert(companies.length===candidates.length);
    });
}

const oracleLib = require('oracle');
runOracle(oracleLib.traceWheat1);
runOracle(oracleLib.traceChaff1);
