let url = 'https://people.cs.umass.edu/~joydeepb/robot.jpg';
let robot = lib220.loadImageFromURL(url);

//imageMap(img: Image, func: (p : Pixel) => Pixel) : Image
function imageMap(img, func){
  let imgCopy = img.copy();
  for(let i = 0; i < imgCopy.width; ++i){
    for(let j = 0; j < imgCopy.height; ++j){
      let p = img.getPixel(i, j);
      let newP = func(p);
      imgCopy.setPixel(i, j, newP);
    }
  }
  return imgCopy;
}

//imageMapXY(img: Image, func: (img: Image, x: number, y: number) => Pixel): Image
function imageMapXY(img, func){
  let imgCopy = img.copy();
  for(let i = 0; i < imgCopy.width; ++i){
    for(let j = 0; j < imgCopy.height; ++j){
      imgCopy.setPixel(i, j, func(img, i, j));
    }
  }
  return imgCopy;
}

//blurPixel(img: Image, x: number, y: number): Pixel
function blurPixel(img, x, y){
  let startX = x - 1;
  let startY = y - 1;
  let endX = x + 1;
  let endY = y + 1;
  let counter = 0;
  let sum = [0, 0, 0];

  for(let i = startX; i <= endX; ++i){
    for(let j = startY; j <= endY; ++j){
      if((i < 0 || j < 0 || j >= img.height || i >= img.width)){
        continue;
      }
      let p = img.getPixel(i, j);
      counter += 1;
      sum[0] += p[0];
      sum[1] += p[1];
      sum[2] += p[2];
    }
  }

  return sum.map(x => x/counter);
}

//blurImage(img: Image): Image
function blurImage(img){
  return imageMapXY(img, blurPixel);
}

// diffLeft(img: Image, x: number, y: number): pixel[]
function diffLeft(img, x, y){
  if(!((x - 1) < 0)){
    let m1 = (img.getPixel(x, y).reduce((x, p) => x + p, 0))/3;
    let m2 = (img.getPixel(x - 1, y).reduce((x, p) => x + p, 0))/3;
    let result = Math.abs(m2 - m1);
    return [result, result, result];
  }
    else{
    return [0, 0, 0];
  }
}
// highlightEdges(img: Image): Image
function highlightEdges(img){
  return imageMapXY(img, diffLeft);
}

//imageMapCond(img: Image, cond: (img: Image, x: number, y: number) => boolean, func: (p: Pixel) => Pixel): Image
function imageMapCond(img, cond, func){
  let imgCopy = img.copy();
  imgCopy = imageMapXY(imgCopy, function(img, i, j){
    if(cond(img, i, j) === true){
      return func(img.getPixel(i, j));
    }
    else{
      return img.getPixel(i, j);
    }
  });
  return imgCopy;
} 

//isGrayish(p: Pixel): boolean
function isGrayish(p){
  return ((Math.max(p[0],p[1],p[2]) - Math.min(p[0],p[1],p[2])) <= (1/3));
}

//makeGrayish(img: Image): Image
function makeGrayish(p){

  if(!isGrayish(p)){
    let avg = (p[0] + p[1] + p[2])/3;
    return [avg, avg, avg];
  }
  else{
    return p;
  }
}

//shiftRGB(robot: Image): Image
function shiftRGB(p){
  return [p[1], p[2], p[0]];
}

//blackenLow(img: Image): Image
function blackenLow(p){
    if(p[0] < (0.333) || p[1] < (0.333) || p[2] < (0.333)){
      if(p[0] < 1/3){
        p[0] = 0;
      }
      if(p[1] < 1/3){
        p[1] = 0;
      }
      if(p[2] < 1/3){
        p[2] = 0;
      }
      return p;
  }
  else{
    return p;
  }
}

// reduceFunctions(fa: ((p: Pixel) => Pixel)[] ): ((x: Pixel) => Pixel)
function reduceFunctions(fa){
  return function(p){
    return fa.reduce((p, func) => func(p), p); 
  };
}

// combineThree(img: Image): Image
function combineThree(img){
  return imageMap(img, reduceFunctions([makeGrayish, shiftRGB, blackenLow]));  
}

// Testing
test('imageMapXY function definition is correct', function() {
  function identity(image, x, y) { return image.getPixel(x, y); }
  let inputImage = lib220.createImage(10, 10, [0, 0, 0]);
  let outputImage = imageMapXY(inputImage, identity);
  let p = outputImage.getPixel(0, 0); // output should be an image, getPixel works
  assert(p.every(c => c === 0)); // every pixel channel is 0
  assert(inputImage !== outputImage); // output should be a different image object
});

function pixelEq (p1, p2) {
  const epsilon = 0.002; // increase for repeated storing & rounding
  return [0,1,2].every(i => Math.abs(p1[i] - p2[i]) <= epsilon);
};

test('identity function with imageMapXY', function() {
  let identityFunction = function(image, x, y ) {
  return image.getPixel(x, y);
  };
  let inputImage = lib220.createImage(10, 10, [0.2, 0.2, 0.2]);
  inputImage.setPixel(0, 0, [0.5, 0.5, 0.5]);
  inputImage.setPixel(5, 5, [0.1, 0.2, 0.3]);
  inputImage.setPixel(2, 8, [0.9, 0.7, 0.8]);
  let outputImage = imageMapXY(inputImage, identityFunction);
  assert(pixelEq(outputImage.getPixel(0, 0), [0.5, 0.5, 0.5]));
  assert(pixelEq(outputImage.getPixel(5, 5), [0.1, 0.2, 0.3]));
  assert(pixelEq(outputImage.getPixel(2, 8), [0.9, 0.7, 0.8]));
  assert(pixelEq(outputImage.getPixel(9, 9), [0.2, 0.2, 0.2]));
});

test('Testing isGrayish', function() {
  //testing IsGrayish with different values to see if the pixel requires to be made grayish or not.
  //Values are tested in both cases if the max - min is greater than and less than 1/3.
  assert(isGrayish([1, 1, 0.8]) === true);
  assert(isGrayish([0.9, 0.55, 0.3]) === false);
  assert(isGrayish([0.9, 0.55, 0.3]) === false);
});


test('Testing makeGrayish', function() {
  //Creating input images in order to test makeGrayish with different values and see if the values are 
  //changed based on the case. 
  const inputImage1 = lib220.createImage(10, 10, [0.6, 0.3, 0.4]);
  const inputImage2 = lib220.createImage(10, 10, [0.75, 0.2, 0.3]);
  const inputImage3 = lib220.createImage(10, 10, [0.1, 0.7, 0.9]);
  //Calling makeGrayish on each input Image. 
  const outputImage1 = imageMap(inputImage1, makeGrayish);
  const outputImage2 = imageMap(inputImage2, makeGrayish);
  const outputImage3 = imageMap(inputImage3, makeGrayish);
  //Assertion to check if the output recieved is only making the image gray if the max - min is greater 
  // than 1/3 and not otherwise. 
  assert(pixelEq(outputImage1.getPixel(3,4), [0.6, 0.301, 0.4]));
  assert(pixelEq(outputImage2.getPixel(3,4), [0.415, 0.415, 0.415]));
  assert(pixelEq(outputImage3.getPixel(3,4), [0.568, 0.568, 0.568]));
  });

  test('Testing blackenLow', function() {
  //Values for input Images are based on checking that only the values below 1/3 then the channel value
  //becomes 0. 
  const inputImage = lib220.createImage(10, 10, [0.7, 0.25, 0.4]);
  const inputImage2 = lib220.createImage(10, 10, [0.8, 0.3, 0.5]);
  //Calling blackenLow on each input Image. 
  let outputImage = imageMap(inputImage, blackenLow);
  const outputImage2 = imageMap(inputImage2, blackenLow);
  //Assertion to check that only the correct values are being set to 0 by blackenLow. 
  assert(pixelEq(outputImage.getPixel(3,2), [0.701, 0, 0.4]));
  assert(pixelEq(outputImage2.getPixel(3,6), [0.8, 0, 0.501]));
});

test('RGB shifted to GBR by shiftRGB function', function() {
  // Create a test image, of size 10 pixels x 10 pixels, and set RGB to some test values.
  const test = lib220.createImage(10, 10, [.6, .3, .8]);
  // Get the result of the function.
  const test_res = imageMap(test, shiftRGB);
  // Read the center pixel.
  const pixelValue = test_res.getPixel(5, 5);
  //Check pixel Equality between test pixel and calculated value
  assert(pixelEq(pixelValue, [0.3, 0.8, 0.6]));
});

test('testing blurImage at random pixel', function(){
  //testing blur image at a random location
  const input = lib220.createImage(10, 10, [0.6, 0.6, 0.6]);
  input.setPixel(3, 3, [0, 0, 0]);
  const outputPixel = blurImage(input).getPixel(3, 3);
  assert(pixelEq(outputPixel, [0.533, 0.533, 0.533]));
});

test('testing blurImage at corner pixel', function(){
  //testing blur image using a corner pixel to ensure it does not check outside of bounds
  const input = lib220.createImage(10, 10, [0.6, 0.6, 0.6]);
  input.setPixel(0, 0, [0, 0, 0]);
  const outputPixel = blurImage(input).getPixel(0, 0);
  assert(pixelEq(outputPixel, [0.45, 0.45, 0.45]));
});

test('testing blurImage at center pixel', function(){
  //testing blur image using the center pixel of the image
  const input = lib220.createImage(10, 10, [1, 1, 1]);
  input.setPixel(5, 5, [0.5, 0.5, 0.5]);
  const outputPixel = blurImage(input).getPixel(5, 5);
  assert(pixelEq(outputPixel, [0.944, 0.944, 0.944]));
});

test('testing highlightEdges edges and diffLeft', function(){
  //tested hightlight Edges after manually calculating pixel values at assigned pixel locations
  const input = lib220.createImage(10, 10, [0.6, 0.6, 0.6]);
  input.setPixel(3, 3, [0.5, 0.5, 0.5]);
  const output = highlightEdges(input);
  assert(pixelEq(output.getPixel(3, 3), [0.098, 0.098, 0.098]));
  assert(pixelEq(output.getPixel(4, 5), [0, 0, 0]));
  assert(pixelEq(output.getPixel(2, 3), [0, 0, 0]));
});

test('testing combineThree', function(){
  //this tests uses 2 test cases, testing at 2 different pixels in the image. We compare the values
  //of directly calling each function and calling combinThree and comparing the values. 
  let inputImg = lib220.createImage(10, 10, [0.5, 0.4, 0.7]);
  let input = [0.5, 0.4, 0.7]
  input = shiftRGB(input);
  input = blackenLow(input);
  let output = makeGrayish(input);
  let input2 = inputImg.getPixel(0, 0);
  input2 = shiftRGB(input2);
  input2 = blackenLow(input2);
  let output2 = makeGrayish(input2);
  let output3 = combineThree(inputImg);
  assert(pixelEq(output, output3.getPixel(5, 5)));
  assert(pixelEq(output2, output3.getPixel(0, 0)));
});
