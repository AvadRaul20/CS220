

//imageMapXY(img: Image, func: (img: Image, x: number, y: number) => Pixel): Image
function imageMapXY(img, func){
  let imgCopy = img.copy();
  for(let i = 0; i < imgCopy.width; ++i){
    for(let j = 0; j < imgCopy.height; ++j){
      imgCopy.setPixel(i, j, func(imgCopy, i, j));
    }
  }
  return imgCopy;
}

let url = 'https://people.cs.umass.edu/~joydeepb/robot.jpg';
let robot = lib220.loadImageFromURL(url);
robot.show()

//imageMask(img: Image, cond: (img: Image, x: number, y: number) => boolean, maskValue: Pixel): Image
function imageMask(img, cond , maskValue){
  let imgCopy = img.copy();
  imgCopy = imageMapXY(imgCopy, function(img, i, j){
    if(cond(img, i, j)){
      return maskValue;
    }
    else{
      return img.getPixel(i, j);
    }
  });
  return imgCopy;
}

let url2 = 'https://people.cs.umass.edu/~joydeepb/robot.jpg';
let robot2 = lib220.loadImageFromURL(url2);
imageMask(robot2, function(img,x,y){ return (y % 10 === 0); }, [1, 0, 0]).show();

//imageMapCond(img: Image, cond: (img: Image, x: number, y: number) => boolean, func: (p: Pixel) => Pixel): Image
function imageMapCond(img, cond, func){
  let imgCopy = img.copy();
  imgCopy = imageMapXY(imgCopy, function(img, i, j){
    if(cond(img, i, j) === true){
      return func(img.getPixel(i, j));
    }
    else{
      return img.getPixel(i, j);
    }
  });
  return imgCopy;
} 

//isGrayish(p: Pixel): boolean
function isGrayish(p){
  return ((Math.max(p[0],p[1],p[2]) - Math.min(p[0],p[1],p[2])) <= (1/3));
}

//makeGrayish(img: Image): Image
function makeGrayish(img){
  return imageMapCond(img, function(img, x, y){return !isGrayish(img.getPixel(x,y));}, 
    function(p){
    let avg = (p[0] + p[1] + p[2])/3;
    return [avg, avg, avg];
  });
}

(makeGrayish(robot2)).show();

//grayHalfImage(img: Image): Image
function grayHalfImage(img){
  return imageMapCond(img, 
    function(img, x, y){
      if(y < (img.height/2) ){
        return !isGrayish(img.getPixel(x,y));
      }
      else{
        return false;
      }
    },
    function(p){
      let avg = (p[0] + p[1] + p[2])/3;
      return [avg, avg, avg];
  });
}

(grayHalfImage(robot2)).show();

//blackenLow(img: Image): Image
function blackenLow(img){
  return imageMapCond(img, 
  function(img, x, y){
    let p = img.getPixel(x, y);
    if(p[0] < (1/3) || p[1] < (1/3) || p[2] < (1/3)){
      return true;
    }
    else{
      return false
    }
  }, 
  function(p){
    if(p[0] < 1/3){
      p[0] = 0;
    }
    if(p[1] < 1/3){
      p[1] = 0;
    }
    if(p[2] < 1/3){
      p[2] = 0;
    }
    return p;
  });
}

blackenLow(robot2).show();

//Testing
test('imageMapXY function definition is correct', function() {
function identity(image, x, y) { return image.getPixel(x, y); }
let inputImage = lib220.createImage(10, 10, [0, 0, 0]);
let outputImage = imageMapXY(inputImage, identity);
let p = outputImage.getPixel(0, 0); // output should be an image, getPixel works
assert(p.every(c => c === 0)); // every pixel channel is 0
assert(inputImage !== outputImage); // output should be a different image object
});

function pixelEq (p1, p2) {
const epsilon = 0.002; // increase for repeated storing & rounding
return [0,1,2].every(i => Math.abs(p1[i] - p2[i]) <= epsilon);
};

test('identity function with imageMapXY', function() {
let identityFunction = function(image, x, y ) {
return image.getPixel(x, y);
};
let inputImage = lib220.createImage(10, 10, [0.2, 0.2, 0.2]);
inputImage.setPixel(0, 0, [0.5, 0.5, 0.5]);
inputImage.setPixel(5, 5, [0.1, 0.2, 0.3]);
inputImage.setPixel(2, 8, [0.9, 0.7, 0.8]);
let outputImage = imageMapXY(inputImage, identityFunction);
assert(pixelEq(outputImage.getPixel(0, 0), [0.5, 0.5, 0.5]));
assert(pixelEq(outputImage.getPixel(5, 5), [0.1, 0.2, 0.3]));
assert(pixelEq(outputImage.getPixel(2, 8), [0.9, 0.7, 0.8]));
assert(pixelEq(outputImage.getPixel(9, 9), [0.2, 0.2, 0.2]));
});



test('identity function with imageMask', function() {
//Identity function to use when calling ImageMask.
let identityFunction = function(image, x, y ) { return x % 2 === 0; };
let MaskVal = [0, 0, 1];
let inputImage = lib220.createImage(10, 10, [0.2, 0.2, 0.2]);
//Setting test values in order to check for proper calculations after calling ImageMask.
inputImage.setPixel(2, 0, [0.5, 0.5, 0.5]);
inputImage.setPixel(4, 5, [0.1, 0.2, 0.3]);
inputImage.setPixel(6, 5, [0.1, 0.2, 0.3]);
//Calling of imageMask using inputImage.
let outputImage = imageMask(inputImage, identityFunction, MaskVal);
//Assertion of test values with expected values in order to check for ImageMask's code.
assert(pixelEq(outputImage.getPixel(2, 0), [0, 0, 1]));
assert(pixelEq(outputImage.getPixel(4, 5), [0, 0, 1]));
assert(pixelEq(outputImage.getPixel(6, 5), [0, 0, 1]));
});

test('identity function with imageMapCond', function() {
let inputImage = lib220.createImage(10, 10, [0.2, 0.2, 0.2]);
//Setting test values in order to check for proper calculations after calling imageMapCond.
inputImage.setPixel(1, 2, [0.5, 0.5, 0.5]);
inputImage.setPixel(1, 5, [0.1, 0.2, 0.3]);
inputImage.setPixel(1, 8, [0.1, 0.2, 0.3]);
//Calling of imageMapCond using inputImage.
let outputImage = imageMapCond(inputImage, function(img, x, y){ return x === 1}, function(p){
return [1, 0, 0];
});
//Assertion of test values with expected values in order to check for imageMapCond's code.
assert(pixelEq(outputImage.getPixel(1, 2), [1, 0, 0]));
assert(pixelEq(outputImage.getPixel(1, 5), [1, 0, 0]));
assert(pixelEq(outputImage.getPixel(1, 8), [1, 0, 0]));
});

test('Testing isGrayish', function() {
//testing IsGrayish with different values to see if the pixel requires to be made grayish or not.
//Values are tested in both cases if the max - min is greater than and less than 1/3.
assert(isGrayish([1, 1, 0.8]) === true);
assert(isGrayish([0.9, 0.55, 0.3]) === false);
assert(isGrayish([0.9, 0.55, 0.3]) === false);
});


test('Testing makeGrayish', function() {
//Creating input images in order to test makeGrayish with different values and see if the values are 
//changed based on the case. 
let inputImage1 = lib220.createImage(10, 10, [0.6, 0.3, 0.4]);
let inputImage2 = lib220.createImage(10, 10, [0.75, 0.2, 0.3]);
let inputImage3 = lib220.createImage(10, 10, [0.1, 0.7, 0.9]);
//Calling makeGrayish on each input Image. 
let outputImage1 = makeGrayish(inputImage1);
let outputImage2 = makeGrayish(inputImage2);
let outputImage3 = makeGrayish(inputImage3);
//Assertion to check if the output recieved is only making the image gray if the max - min is greater 
// than 1/3 and not otherwise. 
assert(pixelEq(outputImage1.getPixel(3,4), [0.6, 0.301, 0.4]));
assert(pixelEq(outputImage2.getPixel(3,4), [0.415, 0.415, 0.415]));
assert(pixelEq(outputImage3.getPixel(3,4), [0.568, 0.568, 0.568]));
});

test('Testing grayHalfImage', function() {
//Values are chose to see if the image requires to be made grayish. inputImage does not require to be
//made grayish as the max - min are less than 1/3. However, inputImage2 does need to made grayish
//as max - min > 1/3. 
let inputImage = lib220.createImage(10, 10, [0.6, 0.3, 0.4]);
let inputImage2 = lib220.createImage(10, 10, [0.7, 0.2, 0.3]);
//Calling grayHalfImage on each input Image. 
let outputImage = grayHalfImage(inputImage);
let outputImage2 = grayHalfImage(inputImage2);
//Assertion to check if the output image is being changed only on the top half of the image and not 
//the bottom half. Furthermore, only executes if the values are approved by the isGrayish function
assert(pixelEq(outputImage.getPixel(3,2), [0.6, 0.301, 0.4]));
assert(pixelEq(outputImage2.getPixel(6,4), [0.4, 0.4, 0.4]));
});

test('Testing blackenLow', function() {
//Values for input Images are based on checking that only the values below 1/3 then the channel value
//becomes 0. 
let inputImage = lib220.createImage(10, 10, [0.7, 0.25, 0.4]);
let inputImage2 = lib220.createImage(10, 10, [0.8, 0.3, 0.5]);
//Calling blackenLow on each input Image. 
let outputImage = blackenLow(inputImage);
let outputImage2 = blackenLow(inputImage2);
//Assertion to check that only the correct values are being set to 0 by blackenLow. 
assert(pixelEq(outputImage.getPixel(3,2), [0.701, 0, 0.4]));
assert(pixelEq(outputImage2.getPixel(3,6), [0.8, 0, 0.501]));
});
